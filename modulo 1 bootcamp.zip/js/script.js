window.addEventListener('load', () => console.log('page loaded'));
